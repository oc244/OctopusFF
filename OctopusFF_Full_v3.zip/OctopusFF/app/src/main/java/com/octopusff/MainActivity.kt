package com.octopusff

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt
import kotlin.random.Random

private val Black = Color(0xFF090909)
private val Card = Color(0xFF151515)
private val Card2 = Color(0xFF1D1D1D)
private val Red = Color(0xFFE50914)
private val White = Color(0xFFF5F5F5)
private val Gray = Color(0xFF9E9E9E)
private val Green = Color(0xFF63D68A)

data class Sensitivity(
    val general:Int, val redDot:Int, val x2:Int,
    val x4:Int, val sniper:Int, val freeLook:Int
)

data class Trial(val result:String, val adjustment:String)

fun generateSensitivity(drag:String, learning:Int): Sensitivity {
    val base = 185 + learning.coerceIn(-20,20)
    val offset = when(drag) { "قصير" -> 8; "طويل" -> -8; else -> 0 }
    fun v(x:Int) = (x + offset + Random.nextInt(-2,3)).coerceIn(0,200)
    return Sensitivity(v(base),v(base-8),v(base-20),v(base-30),v(base-55),v(base-5))
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OctopusApp(this) }
    }
}

@Composable
fun OctopusApp(context: Context) {
    var page by remember { mutableStateOf(0) }
    var drag by remember { mutableStateOf("متوسط") }
    var learning by remember { mutableStateOf(0) }
    var sensitivity by remember { mutableStateOf(generateSensitivity(drag, learning)) }
    var trials by remember { mutableStateOf(listOf<Trial>()) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary=Red, background=Black, surface=Card, onSurface=White
    )) {
        Scaffold(
            containerColor = Black,
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF101010)) {
                    listOf("الرئيسية","التحليل","السجل","الإعدادات").forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = page == i,
                            onClick = { page = i },
                            icon = { Text(listOf("⌂","✦","▣","⚙")[i], fontSize=20.sp) },
                            label = { Text(label, fontSize=10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor=Red, selectedTextColor=Red,
                                unselectedIconColor=Gray, unselectedTextColor=Gray,
                                indicatorColor=Color(0xFF281013)
                            )
                        )
                    }
                }
            }
        ) { pad ->
            when(page) {
                0 -> Home(pad, sensitivity, drag) {
                    sensitivity = generateSensitivity(drag, learning)
                }
                1 -> Analysis(pad) { answer ->
                    learning = (learning + when(answer) {
                        "فوق الرأس" -> -4
                        "تحت الرأس" -> 4
                        else -> 0
                    }).coerceIn(-20,20)
                    sensitivity = generateSensitivity(drag, learning)
                    trials = listOf(
                        Trial(answer, if(answer=="فوق الرأس") "تقليل الحساسية قليلًا"
                        else if(answer=="تحت الرأس") "رفع الحساسية قليلًا" else "الإعداد مناسب")
                    ) + trials.take(9)
                }
                2 -> History(pad, trials)
                3 -> SettingsPage(pad, context)
            }
        }
    }
}

@Composable
fun Header(title:String, subtitle:String) {
    Column(Modifier.fillMaxWidth().padding(horizontal=18.dp, vertical=18.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("أخطبوط FF", color=White, fontSize=27.sp, fontWeight=FontWeight.ExtraBold)
                Text(title, color=Red, fontSize=12.sp, fontWeight=FontWeight.Bold)
            }
            Surface(shape=RoundedCornerShape(14.dp), color=Color(0xFF241014)) {
                Text("● جاهز", color=Green, fontSize=11.sp,
                    modifier=Modifier.padding(horizontal=12.dp, vertical=8.dp))
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(subtitle, color=Gray, fontSize=12.sp)
    }
}

@Composable
fun Home(
    pad:PaddingValues, s:Sensitivity, drag:String, onGenerate:()->Unit
) {
    Column(Modifier.fillMaxSize().padding(pad)) {
        Header("لوحة التحكم", "توصيات حساسية مخصصة لجهازك")
        LazyColumn(
            contentPadding=PaddingValues(horizontal=18.dp, vertical=4.dp),
            verticalArrangement=Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(colors=CardDefaults.cardColors(containerColor=Card),
                    shape=RoundedCornerShape(22.dp), modifier=Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(18.dp), verticalAlignment=Alignment.CenterVertically) {
                        Surface(Modifier.size(54.dp), RoundedCornerShape(16.dp), color=Color(0xFF2A0D10)) {
                            Box(contentAlignment=Alignment.Center) { Text("📱", fontSize=25.sp) }
                        }
                        Spacer(Modifier.width(14.dp))
                        Column {
                            Text("الجهاز", color=Gray, fontSize=11.sp)
                            Text("Red Magic 5G", color=White, fontSize=18.sp, fontWeight=FontWeight.Bold)
                            Text("ملف أداء مخصص", color=Green, fontSize=11.sp)
                        }
                    }
                }
            }
            item {
                Text("الحساسية الحالية", color=White, fontSize=18.sp, fontWeight=FontWeight.Bold)
            }
            item { SensitivityCard(s) }
            item {
                Card(colors=CardDefaults.cardColors(containerColor=Card2),
                    shape=RoundedCornerShape(20.dp), modifier=Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("أسلوب السحب", color=Gray, fontSize=11.sp)
                        Text(drag, color=White, fontSize=17.sp, fontWeight=FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Button(onClick=onGenerate, colors=ButtonDefaults.buttonColors(containerColor=Red),
                            modifier=Modifier.fillMaxWidth().height(52.dp),
                            shape=RoundedCornerShape(16.dp)) {
                            Text("توليد إعداد جديد  ✦", fontWeight=FontWeight.Bold)
                        }
                    }
                }
            }
            item {
                Text("⚠ التوصيات تجريبية؛ لا تضمن نسبة هيدشوت ثابتة.", color=Gray, fontSize=11.sp,
                    modifier=Modifier.padding(bottom=8.dp))
            }
        }
    }
}

@Composable
fun SensitivityCard(s:Sensitivity) {
    Card(colors=CardDefaults.cardColors(containerColor=Card),
        shape=RoundedCornerShape(20.dp), modifier=Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            listOf("General" to s.general, "Red Dot" to s.redDot, "2X Scope" to s.x2,
                "4X Scope" to s.x4, "Sniper" to s.sniper, "Free Look" to s.freeLook)
                .forEach { (name,value) ->
                    Row(Modifier.fillMaxWidth().padding(vertical=7.dp),
                        horizontalArrangement=Arrangement.SpaceBetween) {
                        Text(name, color=Gray)
                        Text(value.toString(), color=Red, fontSize=18.sp, fontWeight=FontWeight.ExtraBold)
                    }
                }
        }
    }
}

@Composable
fun Analysis(pad:PaddingValues, onAnswer:(String)->Unit) {
    Column(Modifier.fillMaxSize().padding(pad)) {
        Header("التحليل الذكي", "علّم التطبيق من نتيجة السحب لتحسين التوصيات")
        Column(Modifier.padding(horizontal=18.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Card(colors=CardDefaults.cardColors(containerColor=Card),
                shape=RoundedCornerShape(22.dp), modifier=Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("بعد تجربة السحب، أين ذهبت الطلقة؟", color=White,
                        fontSize=18.sp, fontWeight=FontWeight.Bold)
                    Spacer(Modifier.height(15.dp))
                    listOf("فوق الرأس","على الرأس","تحت الرأس").forEach { a ->
                        OutlinedButton(
                            onClick={onAnswer(a)},
                            modifier=Modifier.fillMaxWidth().height(50.dp),
                            shape=RoundedCornerShape(14.dp),
                            colors=ButtonDefaults.outlinedButtonColors(contentColor=White)
                        ) { Text(a) }
                    }
                }
            }
            Text("التعلم هنا مبني على الملاحظات التي تدخلها أنت داخل التطبيق.", color=Gray, fontSize=11.sp)
        }
    }
}

@Composable
fun History(pad:PaddingValues, trials:List<Trial>) {
    Column(Modifier.fillMaxSize().padding(pad)) {
        Header("السجل", "آخر تجارب التحليل والتعديلات")
        if(trials.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) {
                Text("لا توجد تجارب بعد.\nاذهب إلى التحليل وابدأ أول تجربة.", color=Gray,
                    fontSize=14.sp)
            }
        } else {
            LazyColumn(
                contentPadding=PaddingValues(horizontal=18.dp),
                verticalArrangement=Arrangement.spacedBy(10.dp)
            ) {
                items(trials) { t ->
                    Card(colors=CardDefaults.cardColors(containerColor=Card),
                        shape=RoundedCornerShape(16.dp), modifier=Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(15.dp)) {
                            Text(t.result, color=White, fontWeight=FontWeight.Bold)
                            Text(t.adjustment, color=Gray, fontSize=12.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsPage(pad:PaddingValues, context:Context) {
    Column(Modifier.fillMaxSize().padding(pad)) {
        Header("الإعدادات", "إعدادات أخطبوط FF")
        Column(Modifier.padding(horizontal=18.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            SettingRow("اسم التطبيق", "أخطبوط FF")
            SettingRow("الجهاز", "Red Magic 5G")
            SettingRow("النطاق", "0 - 200")
            SettingRow("الإصدار", "3.0")
            Text("ملاحظة: التطبيق لا يغيّر إعدادات Free Fire تلقائيًا؛ هو أداة توصية وتجربة.", color=Gray, fontSize=11.sp)
        }
    }
}

@Composable
fun SettingRow(title:String, value:String) {
    Card(colors=CardDefaults.cardColors(containerColor=Card),
        shape=RoundedCornerShape(16.dp), modifier=Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp), horizontalArrangement=Arrangement.SpaceBetween) {
            Text(title, color=Gray)
            Text(value, color=White, fontWeight=FontWeight.Bold)
        }
    }
}
